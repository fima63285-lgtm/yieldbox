# YieldBox v1

Testnet-first non-custodial DeFi starter.

## Run
Node.js 20+

npm install
cp .env.example .env.local
npm run dev

Open http://localhost:3000

## Important
This starter does not accept real user funds, does not promise yield, and does not contain a mainnet vault. Before production: legal review, smart-contract audit, testnet testing, monitoring, and secure deployment.
