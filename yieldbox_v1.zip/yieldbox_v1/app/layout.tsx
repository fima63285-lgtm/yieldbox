import './globals.css';
export const metadata={title:'YieldBox — DeFi dashboard',description:'Non-custodial DeFi testnet application'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>}
