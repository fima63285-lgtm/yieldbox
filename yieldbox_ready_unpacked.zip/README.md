# YieldBox v1

A polished Next.js 16 testnet-first DeFi dashboard. It does not custody funds, promise returns, or contain mainnet contracts.

## Run

Requires Node.js 20.9+.

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Production path
1. Choose network/protocols.
2. Implement and test non-custodial contracts.
3. Add wallet connector and transaction simulation.
4. Add indexed on-chain data/backend.
5. Add authentication/admin controls.
6. Independent smart-contract audit.
7. Legal/compliance review before accepting real funds.
8. Deploy to hosting and mainnet only after the above.
