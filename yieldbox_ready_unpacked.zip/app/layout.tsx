import './globals.css';
import Link from 'next/link';
export const metadata={title:'YieldBox — DeFi Yield',description:'Non-custodial DeFi yield dashboard'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ru"><body><header><Link href="/" className="brand">YieldBox</Link><nav><Link href="/dashboard">Dashboard</Link><Link href="/strategies">Strategies</Link><Link href="/referrals">Referrals</Link></nav><span className="badge">TESTNET</span></header>{children}<footer>YieldBox • Non-custodial • Testnet only</footer></body></html>}
