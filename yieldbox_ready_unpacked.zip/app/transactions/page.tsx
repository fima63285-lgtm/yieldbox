export default function Transactions(){return <main className="page"><h1>Transactions</h1><div className="card"><p className="muted">No transactions yet.</p></div></main>}
